# Market-Mix-Modelling-Adstock-Optimization-
Marketing mix modeling (MMM) is a statistical analysis such as multivariate regressions on sales and marketing time series data to estimate the impact of various marketing activities (marketing mix) on sales.
Here Marketing time series data is the data about amount of money we spend over the time on various advertising activities such as TV advertising,Newspaper Paper Advertising etc.

Suppose if we spend 1M dollars each on various activities like TV Ads,Radio Ads,Newspaper Ads and in that month we have a sales of 15M Dollars 
Companies Wants to know Which advertising activities contributes to increase total sales by performing Market Mix Modelling we can calculate the contribution of each activities to the sales.
We can find answers to questions which are mentioned below.
* What will be our sales if we spend 1.5M on TV,0.5M on radio and 1M on Newspaper Ads what will be our sales,will it gives rise to our sales.
* How much percent of sales are occured due TV,Radio and Radio.
* If we dont spend any money on advertising what will be our sales.
By Finding answers to such question companies can optimize budget on advertising.


